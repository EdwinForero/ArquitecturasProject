package co.edu.unipiloto.VmsFinal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VmsFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}

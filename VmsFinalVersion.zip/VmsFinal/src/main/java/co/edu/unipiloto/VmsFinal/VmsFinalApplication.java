package co.edu.unipiloto.VmsFinal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VmsFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(VmsFinalApplication.class, args);
	}

}

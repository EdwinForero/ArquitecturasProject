/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unipiloto.VmsFinal.controller;

import co.edu.unipiloto.VmsFinal.Models.Mensaje;
import co.edu.unipiloto.VmsFinal.Models.Panel;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import co.edu.unipiloto.VmsFinal.Vista.MensajeInterface;
import co.edu.unipiloto.VmsFinal.Vista.PanelInterface;
import co.edu.unipiloto.VmsFinal.Vista.RegistroMensajeInterface;
import java.text.SimpleDateFormat;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author david
 */
@RestController
@RequestMapping("/api/")
@CrossOrigin(origins = "http://localhost:4200/")
public class MensajeController {

    @Autowired
    PanelInterface panelI;

    @Autowired
    private RegistroMensajeInterface mensajeRegistro;
    @Autowired
    private MensajeInterface mensajeVista;

    @GetMapping("/msgs")
    public ResponseEntity<?> getAllMensajes() {
        List<Mensaje> msg = mensajeVista.findAll();
        if (msg.size() > 0) {

            return new ResponseEntity<List<Mensaje>>(msg, HttpStatus.OK);

        } else {

            return new ResponseEntity<>("No se encontraron Mensajes", HttpStatus.NOT_FOUND);

        }
    }

    @DeleteMapping("/msgs/{id}")
    public ResponseEntity<?> eliminarMensaje(@PathVariable("id") String id) {
        Optional<Mensaje> mensaje = mensajeVista.findById(id);
        if (mensaje.isPresent()) {
            Mensaje deleteMensaje = mensaje.get();

            mensajeVista.delete(deleteMensaje);

            return new ResponseEntity<>(deleteMensaje, HttpStatus.OK);

        } else {

            return new ResponseEntity<>("No se encontraron Paneles", HttpStatus.NOT_FOUND);

        }

    }

    //MENSAJES METODOS REST
    @PostMapping("/msgs/{id}")
    public ResponseEntity<?> createMessage(@PathVariable("id") String id, @RequestBody Mensaje msg) {
        try {

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date = sdf.format(new Date(System.currentTimeMillis()));
            msg.setCreatedAt(date);
            msg.setUpdatedAt(date);
            msg.setPanelId(id);
            mensajeVista.save(msg);
            mensajeRegistro.save(msg);
            return new ResponseEntity<Mensaje>(msg, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("msgsAsignar/{id}")
    public ResponseEntity<?> asignarMensajePanel(@PathVariable("id") String id) {
        Optional<Panel> panelId = panelI.findById(id);
        List<Mensaje> msg = mensajeVista.findAll();
        Panel panel = panelId.get();
        for (Mensaje m : msg) {
            if (m.getPanelId().equals(id)) {
                panel.setMensajeActual(m.getMessage());
                panelI.save(panel);
            }
        }
        return new ResponseEntity<>(panel, HttpStatus.OK);
    }

    @GetMapping("msgs/{id}")
    public ResponseEntity<?> findMessageById(@PathVariable("id") String id) {
        Optional<Mensaje> msgid = mensajeVista.findById(id);
        if (msgid.isPresent()) {

            return new ResponseEntity<>(msgid.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el mensaje", HttpStatus.NOT_FOUND);
        }

    }

    @PutMapping("msgs/{id}")
    public ResponseEntity<?> updateMessageById(@PathVariable("id") String id, @RequestBody Mensaje message) {
        Optional<Mensaje> msgId = mensajeVista.findById(id);
        if (msgId.isPresent()) {
            Mensaje updateMensaje = msgId.get();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date = sdf.format(new Date(System.currentTimeMillis()));
            updateMensaje.setMessage(message.getMessage() != null ? message.getMessage() : updateMensaje.getMessage());
            updateMensaje.setUpdatedAt(date);
            mensajeVista.save(updateMensaje);
            mensajeRegistro.save(updateMensaje);
            return new ResponseEntity<>(updateMensaje, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el mensaje", HttpStatus.NOT_FOUND);
        }

    }

}

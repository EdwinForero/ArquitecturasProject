/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unipiloto.VmsFinal.controller;

import co.edu.unipiloto.VmsFinal.Models.Panel;
import co.edu.unipiloto.VmsFinal.Models.Sensores;
import co.edu.unipiloto.VmsFinal.Vista.SensoresInterface;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author david
 */
@RestController
public class SensoresController {

    @Autowired
    private SensoresInterface sensoresInterface;

    @PostMapping("/addSensor")
    public ResponseEntity<?> createSensor(@RequestBody Sensores sensor) {
        try {
            sensoresInterface.save(sensor);
            return new ResponseEntity<Sensores>(sensor, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("editSensor/{id}")
    public ResponseEntity<?> updatePanelById(@PathVariable("id") String id, @RequestBody Sensores sensor) {
        Optional<Sensores> sensorId = sensoresInterface.findById(id);
        if (sensorId.isPresent()) {
            Sensores updateSensores = sensorId.get();
            updateSensores.setHighway(sensor.getHighway());
            updateSensores.setKilometer(sensor.getKilometer());
            updateSensores.setLocation(sensor.getLocation());
            updateSensores.setName(sensor.getName());
            updateSensores.setState(sensor.getState());
            updateSensores.setType(sensor.getType());

            sensoresInterface.save(updateSensores);
            return new ResponseEntity<>(updateSensores, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el mensaje", HttpStatus.NOT_FOUND);
        }

    }

}

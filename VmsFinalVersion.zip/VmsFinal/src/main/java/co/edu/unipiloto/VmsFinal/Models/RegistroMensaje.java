/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unipiloto.VmsFinal.Models;

import com.sun.istack.NotNull;
import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import co.edu.unipiloto.VmsFinal.Vista.MensajeInterface;

/**
 *
 * @author david
 */
@Document(collection = "RegistroMensaje")
public class RegistroMensaje implements Serializable {

    @Id
    @NotNull
    private String registroId;
    private String panelId;
    private String message;
    private String responsableId;
    private String createdAt;
    private String updatedAt;
    private String messageId;

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getResponsableId() {
        return responsableId;
    }

    public void setResponsableId(String responsableId) {
        this.responsableId = responsableId;
    }

    public RegistroMensaje() {

    }

    public RegistroMensaje(Mensaje msg) {
        this.messageId = msg.getMessageId();
        this.panelId = msg.getPanelId();
        this.message = msg.getMessage();
        this.createdAt = msg.getCreatedAt();
        this.updatedAt = msg.getUpdatedAt();
    }

    public String getRegistroId() {
        return registroId;
    }

    public void setRegistroId(String registroId) {
        this.registroId = registroId;
    }

    public String getMessageId() {
        return messageId;
    }

    public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getPanelId() {
        return panelId;
    }

    public void setPanelId(String panelId) {
        this.panelId = panelId;
    }
}

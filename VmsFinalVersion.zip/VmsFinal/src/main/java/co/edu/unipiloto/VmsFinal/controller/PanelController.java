/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unipiloto.VmsFinal.controller;

import co.edu.unipiloto.VmsFinal.Models.Mensaje;
import co.edu.unipiloto.VmsFinal.Models.Panel;
import co.edu.unipiloto.VmsFinal.Models.RegistroEvento;
import co.edu.unipiloto.VmsFinal.Models.RegistroMensaje;
import co.edu.unipiloto.VmsFinal.Models.Sensores;
import co.edu.unipiloto.VmsFinal.Vista.MensajeInterface;
import co.edu.unipiloto.VmsFinal.Vista.PanelInterface;
import co.edu.unipiloto.VmsFinal.Vista.RegistroEventoInterface;
import co.edu.unipiloto.VmsFinal.Vista.RegistroMensajeInterface;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author david
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200/")
public class PanelController {

    @Autowired
    private PanelInterface panelI;

    @Autowired
    private RegistroMensajeInterface registroMensaje;

    @Autowired
    private MensajeInterface mensajeInterface;

    @GetMapping("/paneles")
    public ResponseEntity<?> getAllPanels() {
        List<Panel> panel = panelI.findAll();
        if (panel.size() > 0) {

            return new ResponseEntity<List<Panel>>(panel, HttpStatus.OK);

        } else {

            return new ResponseEntity<>("No se encontraron Paneles", HttpStatus.NOT_FOUND);

        }
    }

    @GetMapping("paneles/{id}")
    public ResponseEntity<?> findMessageById(@PathVariable("id") String id) {
        Optional<Panel> panelId = panelI.findById(id);
        if (panelId.isPresent()) {

            return new ResponseEntity<>(panelId.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el panel", HttpStatus.NOT_FOUND);
        }

    }

    @GetMapping("/mensajeActual/{id}")
    public ResponseEntity<?> mensajeActualPanel(@PathVariable("id") String id) {
        List<Panel> panel = panelI.findAll();
        String mensajeActual = "";

        for (Panel p : panel) {
            if (p.getPanelId().equals(id)) {
                if (p.getState().equals("Activo")) {
                    return new ResponseEntity(p.getMensajeActual(), HttpStatus.OK);
                } else  {
                    p.setMensajeActual("");
                    panelI.save(p);
                    return new ResponseEntity("El panel se encuentra inactivo", HttpStatus.OK);
                }
               
            }
        }
        return new ResponseEntity<String>("No se encontro panel con mensaje Actual", HttpStatus.OK);
    }

    @GetMapping("/panelesHistorial/{id}")
    public ResponseEntity<?> historialPanel(@PathVariable("id") String id) {
        List<Mensaje> historialMensajes = registroMensaje.findAll();
        List<Mensaje> mensajes = new ArrayList();

        for (Mensaje m : historialMensajes) {
            if (m.getPanelId().equals(id)) {
                mensajes.add(m);
            }
        }

        return new ResponseEntity<>(mensajes, HttpStatus.OK);
    }

    @DeleteMapping("/paneles/{id}")
    public ResponseEntity<?> eliminarPanel(@PathVariable("id") String id) {
        Optional<Panel> panelId = panelI.findById(id);
        if (panelId.isPresent()) {
            Panel deletePanel = panelId.get();

            panelI.delete(deletePanel);

        }

        return new ResponseEntity<>("No se encontraron Paneles", HttpStatus.NOT_FOUND);

    }

    @PostMapping("/paneles")
    public ResponseEntity<?> createPanel(@RequestBody Panel panel) {
        try {
            panelI.save(panel);
            return new ResponseEntity<Panel>(panel, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("paneles/{id}")
    public ResponseEntity<?> updatePanelById(@PathVariable("id") String id, @RequestBody Panel panel) {
        Optional<Panel> panelId = panelI.findById(id);
        if (panelId.isPresent()) {

            Panel updatePanel = panelId.get();
            updatePanel.setHighway(panel.getHighway());
            updatePanel.setKilometer(panel.getKilometer());
            updatePanel.setLatitud(panel.getLatitud());
            updatePanel.setLocation(panel.getLocation());
            updatePanel.setLongitud(panel.getLongitud());
            updatePanel.resetMsg();
            updatePanel.setName(panel.getName());
            updatePanel.setState(panel.getState());
            updatePanel.setType(panel.getType());
            updatePanel.setMensajeActual(panel.getMensajeActual());
            panelI.save(updatePanel);
            return new ResponseEntity<>(updatePanel, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el mensaje", HttpStatus.NOT_FOUND);
        }

    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package co.edu.unipiloto.VmsFinal.Vista;

import co.edu.unipiloto.VmsFinal.Models.Mensaje;
import co.edu.unipiloto.VmsFinal.Models.RegistroMensaje;
import java.io.Serializable;
import org.springframework.data.mongodb.repository.MongoRepository;

/**
 *
 * @author david
 */
public interface RegistroMensajeInterface extends MongoRepository<Mensaje,Serializable>{
    
}

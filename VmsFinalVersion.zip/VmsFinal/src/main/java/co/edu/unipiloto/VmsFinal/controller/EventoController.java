/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unipiloto.VmsFinal.controller;

import co.edu.unipiloto.VmsFinal.Models.Evento;
import co.edu.unipiloto.VmsFinal.Models.Panel;
import co.edu.unipiloto.VmsFinal.Models.RegistroEvento;
import co.edu.unipiloto.VmsFinal.Vista.EventoInterface;
import co.edu.unipiloto.VmsFinal.Vista.PanelInterface;
import co.edu.unipiloto.VmsFinal.Vista.RegistroEventoInterface;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author david
 */
@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:4200/")
public class EventoController {

    @Autowired
    private RegistroEventoInterface rEventoVista;

    @Autowired
    private PanelInterface panelI;



    @Autowired
    private EventoInterface eventoVista;

    //EVENTO REST
    @GetMapping("/evento")
    public ResponseEntity<?> getAllEventos() {
        List<Evento> evento = eventoVista.findAll();
        if (evento.size() > 0) {

            return new ResponseEntity<List<Evento>>(evento, HttpStatus.OK);

        } else {

            return new ResponseEntity<>("No se encontraron Mensajes", HttpStatus.NOT_FOUND);

        }
    }

    @GetMapping("eventoId/{id}")
    public ResponseEntity<?> findEventoById(@PathVariable("id") String id) {
        Optional<Evento> eventoId = eventoVista.findById(id);
        if (eventoId.isPresent()) {

            return new ResponseEntity<>(eventoId.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el panel", HttpStatus.NOT_FOUND);
        }

    }

  
    @GetMapping("/evento/{date}/{dateFin}")
    public ResponseEntity<?> date(@PathVariable String date, @PathVariable String dateFin) {
        List<Evento> eventos = eventoVista.findAll();
        List<Evento> eventoList = new ArrayList<>();
        LocalDate d = LocalDate.parse(date);
        LocalDate dF = LocalDate.parse(dateFin);

        for (Evento e : eventos) {
            LocalDate updatedAt = LocalDate.parse(e.getUpdatedAt());
            if ((updatedAt.isAfter(d) && updatedAt.isBefore(dF))
                    || updatedAt.isEqual(d) || updatedAt.isEqual(dF)) {
                eventoList.add(e);
            }

        }
        return new ResponseEntity<>(eventoList, HttpStatus.OK);
    }

    @PostMapping("/evento")
    public ResponseEntity<?> createEvento(@RequestBody Evento evento) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date = sdf.format(new Date(System.currentTimeMillis()));
            evento.setCreatedAt(date);
            evento.setUpdatedAt(date);
            evento.setEstado("Creado");
            eventoVista.save(evento);
            return new ResponseEntity<Evento>(evento, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("evento/{id}")
    public ResponseEntity<?> updateEvento(@PathVariable("id") String id, @RequestBody Evento evento) {
        Optional<Evento> eventoId = eventoVista.findById(id);
        if (eventoId.isPresent()) {
            RegistroEvento registroEvento = new RegistroEvento(evento);
            rEventoVista.save(registroEvento);
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date = sdf.format(new Date(System.currentTimeMillis()));
            Evento updateEvento = new Evento();
            updateEvento = eventoId.get();
            updateEvento.setDescription(evento.getDescription());
            updateEvento.setCarretera(evento.getCarretera());
            updateEvento.setEventType(evento.getEventType());
            updateEvento.setUpdatedAt(date);
            updateEvento.setEstado("Actualizado");
            eventoVista.save(updateEvento);
            return new ResponseEntity<>(updateEvento, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el mensaje", HttpStatus.NOT_FOUND);
        }

    }

    @GetMapping("finishEvent/{id}")
    public ResponseEntity<?> finishEvent(@PathVariable("id") String id) {
        Optional<Evento> eventoId = eventoVista.findById(id);
        if (eventoId.isPresent()) {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date = sdf.format(new Date(System.currentTimeMillis()));
            Evento updateEvento = new Evento();
            updateEvento = eventoId.get();
            updateEvento.setUpdatedAt(date);
            updateEvento.setEstado("Finalizado");
            updateEvento.setFinishedAt(updateEvento.getUpdatedAt());
            eventoVista.save(updateEvento);
            return new ResponseEntity<>(updateEvento, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el mensaje", HttpStatus.NOT_FOUND);
        }

    }

    @GetMapping("panelesCerca/{id}")
    @ResponseBody
    public ResponseEntity<?> panelesCerca(@PathVariable String id) {
        String carretera = "";
        int kilometer = 0;
        List<Panel> paneles = panelI.findAll();
        List<Panel> panelDistancia = new ArrayList<>();

        for (Evento e : eventoVista.findAll()) {
            if (e.getReporteId().equals(id)) {
                carretera = e.getCarretera();
                break;
            }
        }

        String[] datos = carretera.split(" ");
        carretera = datos[0];
        kilometer = Integer.parseInt(datos[1]);

        for (Panel p : paneles) {
            if (p.getHighway().equals(carretera)){
                panelDistancia.add(p);
            }
        }

        return new ResponseEntity<>(panelDistancia, HttpStatus.OK);
    }

    @GetMapping("historialEvento/{id}")
    @ResponseBody
    public ResponseEntity<?> historiaEvento(@PathVariable String id) {
        List<RegistroEvento> historial = new ArrayList<>();
        for (RegistroEvento e : rEventoVista.findAll()) {
            if (e.getEventoId().equals(id)) {
                historial.add(e);
            }
        }
        return new ResponseEntity<>(historial, HttpStatus.OK);
    }

    @GetMapping("eventosDias/{dias}")
    @ResponseBody
    public ResponseEntity<?> eventosRangoTiempo(@PathVariable String dias) {
        long days = Long.parseLong(dias);
        List<Evento> historial = new ArrayList<>();
        LocalDate rFinal = LocalDate.now();
        LocalDate rInicial = rFinal.minusDays(days);

        for (Evento e : eventoVista.findAll()) {
            LocalDate updatedAt = LocalDate.parse(e.getUpdatedAt());

            if ((updatedAt.isBefore(rFinal) && updatedAt.isAfter(rInicial))
                    || updatedAt.isEqual(rInicial) || updatedAt.isEqual(rFinal)) {
                historial.add(e);
            }
        }
        return new ResponseEntity<>(historial, HttpStatus.OK);
    }
}

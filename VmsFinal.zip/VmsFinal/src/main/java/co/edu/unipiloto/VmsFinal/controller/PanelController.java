/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unipiloto.VmsFinal.controller;

import co.edu.unipiloto.VmsFinal.Models.Mensaje;
import co.edu.unipiloto.VmsFinal.Models.Panel;
import co.edu.unipiloto.VmsFinal.Models.Sensores;
import co.edu.unipiloto.VmsFinal.Vista.PanelInterface;
import java.util.Date;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author david
 */
@RestController
public class PanelController {
    @Autowired
    private PanelInterface panelI;    

    @PostMapping("/panel")
    public ResponseEntity<?> createPanel(@RequestBody Panel panel) {
        try {
            panelI.save(panel);
            return new ResponseEntity<Panel>(panel, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

  @PutMapping("panel/{id}")
    public ResponseEntity<?> updatePanelById(@PathVariable("id") String id, @RequestBody Panel panel) {
        Optional<Panel> panelId = panelI.findById(id);
        if (panelId.isPresent()) {
            Panel updatePanel = panelId.get();
            updatePanel.setHighway(panel.getHighway());
            updatePanel.setKilometer(panel.getKilometer());
            updatePanel.setLatitud(panel.getLatitud());
            updatePanel.setLocation(panel.getLocation());
            updatePanel.setLongitud(panel.getLongitud());
            updatePanel.resetMsg();
            updatePanel.setName(panel.getName());
            updatePanel.setState(panel.getState());
            updatePanel.setType(panel.getType());
 
            panelI.save(updatePanel);
            return new ResponseEntity<>(updatePanel, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el mensaje", HttpStatus.NOT_FOUND);
        }

    }


    
}

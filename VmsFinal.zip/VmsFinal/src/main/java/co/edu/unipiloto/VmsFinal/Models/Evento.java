/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unipiloto.VmsFinal.Models;

import com.sun.istack.NotNull;
import java.io.Serializable;
import java.util.Date;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 *
 * @author david
 */
@Document(collection = "Evento")
public class Evento implements Serializable {
    @Id
    @NotNull
    private String reporteId;
    private String eventType;
    private String description;
    private String userId;
    private Date createdAt;
    private Date finishedAt;
    private Date updatedAt;


    public Evento(String reporterId, String eventType, String description, String userId) {
        this.reporteId = reporterId;
        this.eventType = eventType;
        this.description = description;
        this.userId = userId;
        this.createdAt = new Date(System.currentTimeMillis());
        
       
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public Evento() {
    }

    public String getReporterId() {
        return reporteId;
    }

    public void setReporterId(String reporterId) {
        this.reporteId = reporterId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getFinishedAt() {
        return finishedAt;
    }

    public void setFinishedAt(Date finishedAt) {
        this.finishedAt = finishedAt;
    }

}

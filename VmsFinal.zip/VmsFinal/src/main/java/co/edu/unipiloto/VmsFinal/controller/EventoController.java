/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unipiloto.VmsFinal.controller;

import co.edu.unipiloto.VmsFinal.Models.Evento;
import co.edu.unipiloto.VmsFinal.Models.RegistroEvento;
import co.edu.unipiloto.VmsFinal.Vista.EventoInterface;
import co.edu.unipiloto.VmsFinal.Vista.RegistroEventoInterface;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author david
 */
@RestController
public class EventoController {

    @Autowired
    private RegistroEventoInterface rEventoVista;

    @Autowired
    private EventoInterface eventoVista;

    //EVENTO REST
    @GetMapping("/evento")
    public ResponseEntity<?> getAllEventos() {
        List<Evento> evento = eventoVista.findAll();
        if (evento.size() > 0) {

            return new ResponseEntity<List<Evento>>(evento, HttpStatus.OK);

        } else {

            return new ResponseEntity<>("No se encontraron Mensajes", HttpStatus.NOT_FOUND);

        }
    }

    @PostMapping("/evento")
    public ResponseEntity<?> createEvento(@RequestBody Evento evento) {
        try {

            eventoVista.save(evento);
            return new ResponseEntity<Evento>(evento, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("evento/{id}")
    public ResponseEntity<?> updateEvento(@PathVariable("id") String id, @RequestBody Evento evento) {
        Optional<Evento> eventoId = eventoVista.findById(id);
        if (eventoId.isPresent()) {
            RegistroEvento registroEvento = new RegistroEvento(evento);
            rEventoVista.save(registroEvento);

            Evento updateEvento = new Evento();
            updateEvento = eventoId.get();
            updateEvento.setDescription(evento.getDescription());
            updateEvento.setUpdatedAt(new Date(System.currentTimeMillis()));
            eventoVista.save(updateEvento);
            return new ResponseEntity<>(updateEvento, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el mensaje", HttpStatus.NOT_FOUND);
        }

    }

    @PutMapping("finishEvent/{id}")
    public ResponseEntity<?> finishEvent(@PathVariable("id") String id, @RequestBody Evento evento) {
        Optional<Evento> eventoId = eventoVista.findById(id);
        if (eventoId.isPresent()) {
            RegistroEvento registroEvento = new RegistroEvento(evento);
            rEventoVista.save(registroEvento);

            Evento updateEvento = new Evento();
            updateEvento = eventoId.get();
            updateEvento.setDescription(evento.getDescription());
            updateEvento.setUpdatedAt(new Date(System.currentTimeMillis()));
            updateEvento.setFinishedAt(updateEvento.getUpdatedAt());
            eventoVista.save(updateEvento);
            return new ResponseEntity<>(updateEvento, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el mensaje", HttpStatus.NOT_FOUND);
        }

    }

}

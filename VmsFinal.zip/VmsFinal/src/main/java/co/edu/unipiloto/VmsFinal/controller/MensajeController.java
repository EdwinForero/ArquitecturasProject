/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unipiloto.VmsFinal.controller;

import co.edu.unipiloto.VmsFinal.Models.Evento;
import co.edu.unipiloto.VmsFinal.Models.Mensaje;
import co.edu.unipiloto.VmsFinal.Models.RegistroEvento;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import co.edu.unipiloto.VmsFinal.Vista.EventoInterface;
import co.edu.unipiloto.VmsFinal.Vista.MensajeInterface;
import co.edu.unipiloto.VmsFinal.Vista.RegistroEventoInterface;

/**
 *
 * @author david
 */
@RestController
public class MensajeController {


    @Autowired
    private MensajeInterface mensajeVista;

    @GetMapping("/msgs")
    public ResponseEntity<?> getAllMensajes() {
        List<Mensaje> msg = mensajeVista.findAll();
        if (msg.size() > 0) {

            return new ResponseEntity<List<Mensaje>>(msg, HttpStatus.OK);

        } else {

            return new ResponseEntity<>("No se encontraron Mensajes", HttpStatus.NOT_FOUND);

        }
    }

    //MENSAJES METODOS REST
    @PostMapping("/msgs")
    public ResponseEntity<?> createMessage(@RequestBody Mensaje msg) {
        try {
            msg.setCreatedAt(new Date(System.currentTimeMillis()));
            mensajeVista.save(msg);
            return new ResponseEntity<Mensaje>(msg, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("msgs/{id}")
    public ResponseEntity<?> findMessageById(@PathVariable("id") String id) {
        Optional<Mensaje> msgid = mensajeVista.findById(id);
        if (msgid.isPresent()) {

            return new ResponseEntity<>(msgid.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el mensaje", HttpStatus.NOT_FOUND);
        }

    }

    @PutMapping("msgs/{id}")
    public ResponseEntity<?> updateMessageById(@PathVariable("id") String id, @RequestBody Mensaje message) {
        Optional<Mensaje> msgid = mensajeVista.findById(id);
        if (msgid.isPresent()) {
            Mensaje updateMensaje = msgid.get();
            updateMensaje.setMessage(message.getMessage() != null ? message.getMessage() : updateMensaje.getMessage());
            updateMensaje.setUpdatedAt(new Date(System.currentTimeMillis()));
            mensajeVista.save(updateMensaje);
            return new ResponseEntity<>(updateMensaje, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el mensaje", HttpStatus.NOT_FOUND);
        }

    }



}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unipiloto.VmsFinal.controller;

import co.edu.unipiloto.VmsFinal.Models.Evento;
import co.edu.unipiloto.VmsFinal.Models.Sensores;
import co.edu.unipiloto.VmsFinal.Models.User;
import co.edu.unipiloto.VmsFinal.Vista.UserInterface;
import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author david
 */
@RestController
public class UserController {

    private UserInterface userInterface;

    @PostMapping("/addUser")
    public ResponseEntity<?> createUser(@RequestBody User user) {
        try {

            userInterface.save(user);
            return new ResponseEntity<User>(user, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

   @PutMapping("editUser/{id}")
    public ResponseEntity<?> updatePanelById(@PathVariable("id") String id, @RequestBody User user) {
        Optional<User> userId = userInterface.findById(id);
        if (userId.isPresent()) {
            User updateUser = userId.get();
            updateUser.setMail(user.getMail());
            updateUser.setPassword(user.getPassword());
            updateUser.setUserLastName(user.getUserLastName());
            updateUser.setUserName(user.getUserName());
            updateUser.setUserType(user.getUserType());

            userInterface.save(updateUser);
            return new ResponseEntity<>(updateUser, HttpStatus.OK);
        } else {
            return new ResponseEntity<>("No se ha encontrado el mensaje", HttpStatus.NOT_FOUND);
        }

    }


    

}

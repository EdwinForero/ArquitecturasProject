/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unipiloto.VmsFinal.Models;

import com.sun.istack.NotNull;
import java.io.Serializable;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 *
 * @author david
 */
@Document(collection = "Paneles")
public class Panel implements Serializable{

    @Id
    @NotNull
    private long panelId;

    private String name;
    private String highway;
    private String kilometer;
    private String location;
    private String longitud;
    private String latitud;
    private String type;
    private String state;
    private String mensajeActual;

    public Panel(String name, String highway, String kilometer, String location, String longitud, String latitud, String type, String state) {
        this.name = name;
        this.highway = highway;
        this.kilometer = kilometer;
        this.location = location;
        this.longitud = longitud;
        this.latitud = latitud;
        this.type = type;
        this.state = state;
    }

    public Panel() {
    }
    

    public void resetMsg(){

      this.mensajeActual = null;

    }



    public String getLongitud() {
        return longitud;
    }

    public void setLongitud(String longitud) {
        this.longitud = longitud;
    }

    public String getMensajeActual() {
        return mensajeActual;
    }

    public void setMensajeActual(String mensajeActual) {
        this.mensajeActual = mensajeActual;
    }



    public long getPanelId() {
        return panelId;
    }

    public void setPanelId(long panelId) {
        this.panelId = panelId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHighway() {
        return highway;
    }

    public void setHighway(String highway) {
        this.highway = highway;
    }

    public String getKilometer() {
        return kilometer;
    }

    public void setKilometer(String kilometer) {
        this.kilometer = kilometer;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }


    public String getLatitud() {
        return latitud;
    }

    public void setLatitud(String latitud) {
        this.latitud = latitud;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

}

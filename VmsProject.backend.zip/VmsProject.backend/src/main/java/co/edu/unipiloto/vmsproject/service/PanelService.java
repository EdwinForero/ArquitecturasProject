/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.vmsproject.service;

import co.edu.unipiloto.main.PersistenceManager;
import co.edu.unipiloto.vmsproject.backend.Mensaje;
import co.edu.unipiloto.vmsproject.backend.PanelMensajeria;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.simple.JSONObject;

@Path("/panel")
@Produces(MediaType.APPLICATION_JSON)
public class PanelService {

    @PersistenceContext(unitName = "vmsDatabase")
    private EntityManager entityManager;

    @PostConstruct
    public void init() {
        try {
            entityManager = PersistenceManager.getInstance().getEntityManagerFactory().createEntityManager();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @POST
    @Path("/add")
    @Produces(MediaType.APPLICATION_JSON)
    public Response createPanel(PanelMensajeria panel) {
        JSONObject resp = new JSONObject();

        PanelMensajeria panelMensajeria = new PanelMensajeria(panel.getName(), panel.getHighway(), panel.getKilometer(), panel.getLocation(), panel.getLongitud(), panel.getLatitud(), panel.getType(), panel.getState());
        entityManager.getTransaction().begin();
        entityManager.persist(panelMensajeria);
        entityManager.getTransaction().commit();
        entityManager.refresh(panelMensajeria);
        resp.put("panelId", panelMensajeria.getPanelId());

        return Response.status(200).header("Access-Control-Allow-Origin", "*").entity(resp).build();
    }
    
    
    @GET
    @Path("/get")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllPaneles() {

        Query query = entityManager.createQuery("Select u from PanelMensajeria u order by u.panelId ASC");
        List<PanelMensajeria> panel = query.getResultList();

        return Response.status(200).header("Access-Control-Allow-Origin", "*").entity(panel).build();
    }
    
    @POST
    @Path("/modificar/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public void editPanel(@PathParam("id") long id, PanelMensajeria panel) {

        PanelMensajeria pnl = entityManager.find(PanelMensajeria.class, id);
        entityManager.getTransaction().begin();
       
        pnl.setName(panel.getName());
        pnl.setHighway(panel.getHighway());
        pnl.setKilometer(panel.getKilometer());
        pnl.setLocation(panel.getLocation());
        pnl.setLongitud(panel.getLongitud());
        pnl.setLatitud(panel.getLatitud());
        pnl.setType(panel.getType());
        pnl.setState(panel.getState());
        entityManager.getTransaction().commit();
        
        
         
    

        //entityManager.getTransaction().begin();
        //int deletedCount = entityManager.createQuery("DELETE FROM Mensaje").executeUpdate();
    }

}

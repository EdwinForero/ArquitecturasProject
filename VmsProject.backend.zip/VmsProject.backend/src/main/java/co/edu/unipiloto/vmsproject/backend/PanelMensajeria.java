package co.edu.unipiloto.vmsproject.backend;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PanelMensajeria implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long panelId;

    private String name;
    private String highway;
    private String kilometer;
    private String location;
    private String longitud;
    private String latitud;
    private String type;
    private String state;

    public PanelMensajeria() {
    }

    public PanelMensajeria(String name, String highway, String kilometer, String location, String longitud, String latitud, String type, String state) {
        this.name = name;
        this.highway = highway;
        this.kilometer = kilometer;
        this.location = location;
        this.longitud = longitud;
        this.latitud = latitud;
        this.type = type;
        this.state = state;
    }

    public long getPanelId() {
        return panelId;
    }

    public void setPanelId(long panelId) {
        this.panelId = panelId;
    }

    public String getLongitud() {
        return longitud;
    }

    public void setLongitud(String longitud) {
        this.longitud = longitud;
    }

    public String getLatitud() {
        return latitud;
    }

    public void setLatitud(String latitud) {
        this.latitud = latitud;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHighway() {
        return highway;
    }

    public void setHighway(String highway) {
        this.highway = highway;
    }

    public String getKilometer() {
        return kilometer;
    }

    public void setKilometer(String kilometer) {
        this.kilometer = kilometer;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

}

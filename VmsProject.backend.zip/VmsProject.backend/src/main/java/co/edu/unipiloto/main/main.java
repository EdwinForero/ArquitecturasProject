/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.main;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.webapp.WebAppContext;

/**
 *
 * @author david
 */
public class main {
    
     public static void main(String[] args) throws Exception {
        WebAppContext root = new WebAppContext();
        Server server;
        String webAppDirLocation = "src/main/webapp/";
        String webPort = System.getenv("Port");
        if (webPort == null || webPort.isEmpty()) {
            webPort = "8080";
        }
        server = new Server(Integer.valueOf(webPort));
        root.setContextPath("/");
        root.setDescriptor(webAppDirLocation + "/WEB-INF/web.xml");
        root.setResourceBase(webAppDirLocation);
        
        
        PersistenceManager.getInstance().getEntityManagerFactory();
        root.setParentLoaderPriority(true);
        server.setHandler(root);
        server.start();
        server.join();
        PersistenceManager.getInstance().closeEntityManagerFactory();
        server.stop();
    }
    
}

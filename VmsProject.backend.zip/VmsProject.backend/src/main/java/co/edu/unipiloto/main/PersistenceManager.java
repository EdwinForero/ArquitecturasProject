/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.main;

import java.util.Date;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author david
 */
public class PersistenceManager {
    public static final boolean DEBUG = true;
    private static final PersistenceManager singleton = new PersistenceManager();
    protected EntityManagerFactory emf;

    public PersistenceManager() {
    }

    public static PersistenceManager getInstance() {

        return singleton;
    }

    public EntityManagerFactory getEntityManagerFactory() {
        if (emf == null) {
            createEntityManagerFactory();

        }
        return emf;
    }

    private void createEntityManagerFactory() {
        emf = Persistence.createEntityManagerFactory("vmsDatabase", System.getProperties());
        if (DEBUG) {
            System.out.println("La persistencia inicia en " + new Date());
        }
    }

    public void closeEntityManagerFactory() {
        if (emf != null) {
            emf.close();
            emf = null;
        }
        if (DEBUG) {
            System.out.println("La persistencia finaliza en " + new Date());
        }
    }
    
}

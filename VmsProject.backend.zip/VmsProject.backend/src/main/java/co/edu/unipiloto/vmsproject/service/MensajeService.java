/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.vmsproject.service;

import co.edu.unipiloto.main.PersistenceManager;
import co.edu.unipiloto.vmsproject.backend.Mensaje;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.DELETE;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.simple.JSONObject;

@Path("/mensajes")
@Produces(MediaType.APPLICATION_JSON)
public class MensajeService {

    @PersistenceContext(unitName = "vmsDatabase")
    private EntityManager entityManager;

    @PostConstruct
    public void init() {
        try {
            entityManager = PersistenceManager.getInstance().getEntityManagerFactory().createEntityManager();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @POST
    @Path("/add")
    @Produces(MediaType.APPLICATION_JSON)
    public Response createMessage(Mensaje mensaje) {
        JSONObject resp = new JSONObject();

        Mensaje msg = new Mensaje(mensaje.getMessage(), mensaje.getResponsible());
        entityManager.getTransaction().begin();
        entityManager.persist(msg);
        entityManager.getTransaction().commit();
        entityManager.refresh(msg);
        resp.put("MessageID", msg.getMessageId());

        return Response.status(200).header("Access-Control-Allow-Origin", "*").entity(resp).build();
    }

    @GET
    @Path("/get")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllMessages() {

        Query query = entityManager.createQuery("Select u from Mensaje u order by u.messageId");
        List<Mensaje> listMessages = query.getResultList();

        return Response.status(200).header("Access-Control-Allow-Origin", "*").entity(listMessages).build();
    }

    @DELETE
    @Path("/eliminar/{id}")
    public void eliminarMessage(@PathParam("id") long id) {

        Mensaje msg = entityManager.find(Mensaje.class, id);
        entityManager.getTransaction().begin();
        entityManager.remove(msg);
        entityManager.getTransaction().commit();

        //entityManager.getTransaction().begin();
        //int deletedCount = entityManager.createQuery("DELETE FROM Mensaje").executeUpdate();
    }

    @POST
    @Path("/modificar/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public void editMessage(@PathParam("id") long id, Mensaje mensaje) {

        Mensaje msg = entityManager.find(Mensaje.class, id);
        entityManager.getTransaction().begin();
        msg.setMessage(mensaje.getMessage());
        msg.setResponsible(mensaje.getResponsible());
        
        entityManager.getTransaction().commit();

        //entityManager.getTransaction().begin();
        //int deletedCount = entityManager.createQuery("DELETE FROM Mensaje").executeUpdate();
    }

}

package co.edu.unipiloto.vmsproject.backend;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class ManejoTransito implements Serializable {

   
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long reporterId;

    private String eventType;
    
    @Column(name = "dateTime", updatable = false, nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Calendar dateTime;

    @Column(name = "date", nullable = false)
    @Temporal(TemporalType.DATE)
    private Calendar date;

    public ManejoTransito() {
    }


    public ManejoTransito(String eventType) {

        this.eventType = eventType;
    }

    public Long getReporterId() {
        return reporterId;
    }

    public void setReporterId(Long reporterId) {
        this.reporterId = reporterId;
    }
    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }
    @PrePersist
    private void creationTimeStamp() {
        dateTime = date = Calendar.getInstance();
    }

    @PreUpdate
    private void updateTimpeStamp() {
        date = Calendar.getInstance();
    }

}

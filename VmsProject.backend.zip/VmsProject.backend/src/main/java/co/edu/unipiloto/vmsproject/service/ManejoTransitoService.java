/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.vmsproject.service;

import co.edu.unipiloto.main.PersistenceManager;
import co.edu.unipiloto.vmsproject.backend.ManejoTransito;
import co.edu.unipiloto.vmsproject.backend.Mensaje;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.simple.JSONObject;

/**
 *
 * @author david
 */
@Path("/manejoTransito")
@Produces(MediaType.APPLICATION_JSON)
public class ManejoTransitoService {

    @PersistenceContext(unitName = "vmsDatabase")
    private EntityManager entityManager;

    @PostConstruct
    public void init() {
        try {
            entityManager = PersistenceManager.getInstance().getEntityManagerFactory().createEntityManager();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @POST
    @Path("/add")
    @Produces(MediaType.APPLICATION_JSON)
    public Response Report(ManejoTransito manejoTransito) {
        JSONObject resp = new JSONObject();

        ManejoTransito mnt = new ManejoTransito(manejoTransito.getEventType());
        entityManager.getTransaction().begin();
        entityManager.persist(mnt);
        entityManager.getTransaction().commit();
        entityManager.refresh(mnt);
        resp.put("MessageID",mnt.getReporterId());

        return Response.status(200).header("Access-Control-Allow-Origin", "*").entity(resp).build();
    }

    @GET
    @Path("/get")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllReports() {

        Query query = entityManager.createQuery("Select u from ManejoTransito u order by u.reporterId");
        List<ManejoTransito> listManejoTransito = query.getResultList();

        return Response.status(200).header("Access-Control-Allow-Origin", "*").entity(listManejoTransito).build();
    }

    
}

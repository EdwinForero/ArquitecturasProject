/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unipiloto.vmsproject.service;

import co.edu.unipiloto.main.PersistenceManager;
import co.edu.unipiloto.vmsproject.backend.Mensaje;
import co.edu.unipiloto.vmsproject.backend.Sensores;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.json.simple.JSONObject;

@Path("/sensores")
@Produces(MediaType.APPLICATION_JSON)
public class SensorService {
    
    
    @PersistenceContext(unitName = "vmsDatabase")
    private EntityManager entityManager;

    @PostConstruct
    public void init() {
        try {
            entityManager = PersistenceManager.getInstance().getEntityManagerFactory().createEntityManager();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @POST
    @Path("/add")
    @Produces(MediaType.APPLICATION_JSON)
    public Response createSensor(Sensores sensor) {
        JSONObject resp = new JSONObject();

        Sensores sns = new Sensores(sensor.getName(),sensor.getHighway(),sensor.getKilometer(),sensor.getLocation(),sensor.getType(),sensor.getState());
        entityManager.getTransaction().begin();
        entityManager.persist(sns);
        entityManager.getTransaction().commit();
        entityManager.refresh(sns);
        resp.put("SensorId", sns.getId());

        return Response.status(200).header("Access-Control-Allow-Origin", "*").entity(resp).build();
    }

    @GET
    @Path("/get")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAllSensors() {

        Query query = entityManager.createQuery("Select u from Sensores u order by u.id");
        List<Sensores> listSensor = query.getResultList();

        return Response.status(200).header("Access-Control-Allow-Origin", "*").entity(listSensor).build();
    }

    @DELETE
    @Path("/eliminar/{id}")
    public void eliminarSensor(@PathParam("id") long id) {

        Sensores sns = entityManager.find(Sensores.class, id);
        entityManager.getTransaction().begin();
        entityManager.remove(sns);
        entityManager.getTransaction().commit();

        //entityManager.getTransaction().begin();
        //int deletedCount = entityManager.createQuery("DELETE FROM Mensaje").executeUpdate();
    }

    @POST
    @Path("/modificar/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public void editSensor(@PathParam("id") long id, Sensores sensor) {

        Sensores sns = entityManager.find(Sensores.class, id);
        entityManager.getTransaction().begin();
        sns.setName(sensor.getName());
        sns.setHighway(sensor.getHighway());
        sns.setKilometer(sensor.getKilometer());
        sns.setLocation(sensor.getLocation());
        sns.setType(sensor.getType());
        sns.setState(sensor.getState());
        
        entityManager.getTransaction().commit();

        //entityManager.getTransaction().begin();
        //int deletedCount = entityManager.createQuery("DELETE FROM Mensaje").executeUpdate();
    }

}
